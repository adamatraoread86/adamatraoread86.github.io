$(document).ready(function() {
JavaJam Mug Club Members get a 10% discount on each cup of coffee!
});
/* $(document).ready(function() {
    JavaJam Mug Club Members get a 10% discount on each cup of coffee!
    }); */